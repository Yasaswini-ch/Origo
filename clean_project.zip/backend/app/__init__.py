"""Application package for the generic-saas-app backend."""
