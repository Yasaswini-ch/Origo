"""Utility helpers for the generic-saas-app backend."""
