// PostCSS configuration used by Create React App.
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
