import React from 'react';
import GeneratorPage from './pages/GeneratorPage';

export default function App() {
  return <GeneratorPage />;
}
