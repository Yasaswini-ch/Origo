"""Models package for database entities."""
